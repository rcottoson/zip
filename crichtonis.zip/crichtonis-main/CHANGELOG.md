# CHANGELOG

## 1.2.0

- Add support for Foundry v10